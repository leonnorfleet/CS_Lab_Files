#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable : 6262)
#pragma warning(disable : 4996)
#include<iostream>
#include<cstring>
#include<cassert>


using namespace std;

const int MAX_WORD_LENGTH = 20;

int editStandards(int distance[], char word1[][MAX_WORD_LENGTH + 1], char word2[][MAX_WORD_LENGTH + 1], int nStandards);
int determineMatchLevel(const int distance[], const char word1[][MAX_WORD_LENGTH + 1], const char word2[][MAX_WORD_LENGTH + 1], int nStandards, const char jeet[]);
void deleteWord(int distance[], char word1[][MAX_WORD_LENGTH + 1], char word2[][MAX_WORD_LENGTH + 1], int pos, int nStandards);
void editTests();
void matchTests();


//Goal is to put a match standard into standard form:
	//Every distance is positive
	//Every word is 1+ letter long, no uppercase
	//No two standards use the same words
///Still comfused as to what a match standard is, ask professor for example


int main() {

	editTests();

	matchTests();

	return 0;
}

//Function Definitions

int editStandards(int distance[], char word1[][MAX_WORD_LENGTH + 1], char word2[][MAX_WORD_LENGTH + 1], int nStandards) {

	if (nStandards < 0) {
		nStandards = 0;
	}

	for (int i = 0; i < nStandards; i++) {
		if (distance[i] < 1) { //non positive num in distance array
			for (int pos = i; pos < nStandards - 1; pos++) {
				distance[pos] = distance[pos + 1];
				strcpy(word1[pos], word1[pos + 1]);
				strcpy(word2[pos], word2[pos + 1]);
			}
			distance[nStandards - 1] = '\0';
			strcpy(word1[nStandards - 1], "\0");
			strcpy(word2[nStandards - 1], "\0");
		}

		if (strcmp(word1[i], "") == 0 || strcmp(word2[i], "") == 0) { //blank string in word1 or word2 arrays
			for (int pos = i; pos < nStandards - 1; pos++) {
				distance[pos] = distance[pos + 1];
				strcpy(word1[pos], word1[pos + 1]);
				strcpy(word2[pos], word2[pos + 1]);
			}
			distance[nStandards - 1] = '\0';
			strcpy(word1[nStandards - 1], "\0");
			strcpy(word2[nStandards - 1], "\0");
		}
	}

	for (int i = 0; i < nStandards; i++) { //uppercase correction
		for (int j = 0; j < strlen(word1[i]); j++) { //word1 correction
			word1[i][j] = tolower(word1[i][j]);
		}

		for (int j = 0; j < strlen(word2[i]); j++) { //word2 correction
			word2[i][j] = tolower(word2[i][j]);
		}
	}

	for (int i = 0; i < nStandards; i++) { //non alphabet character word deletion
		for (int j = 0; j < strlen(word1[i]); j++) { //non alpha word1 check
			if (!isalpha(word1[i][j])) {
				for (int pos = i; pos < nStandards - 1; pos++) {
					distance[pos] = distance[pos + 1];
					strcpy(word1[pos], word1[pos + 1]);
					strcpy(word2[pos], word2[pos + 1]);
				}
				distance[nStandards - 1] = '\0';
				strcpy(word1[nStandards - 1], "\0");
				strcpy(word2[nStandards - 1], "\0");
			}
		}
		for (int j = 0; j < strlen(word2[i]); j++) { //non alpha word2 check
			if (!isalpha(word2[i][j])) {
				for (int pos = i; pos < nStandards - 1; pos++) {
					distance[pos] = distance[pos + 1];
					strcpy(word1[pos], word1[pos + 1]);
					strcpy(word2[pos], word2[pos + 1]);
				}
				distance[nStandards - 1] = '\0';
				strcpy(word1[nStandards - 1], "\0");
				strcpy(word2[nStandards - 1], "\0");
			}
		}
	}

	for (int i = nStandards - 1; i > 0; i--) { //duplication deletion / distances
		int dupes = 0;
		for (int j = 0; j < nStandards; j++) {
			if (strcmp(word1[i], word1[j]) == 0) {
				dupes++;
			}
		}
		if (dupes > 1) {
			for (int pos = i; pos < nStandards - 1; pos++) {
				distance[pos] = distance[pos + 1];
				strcpy(word1[pos], word1[pos + 1]);
				strcpy(word2[pos], word2[pos + 1]);
			}
			distance[nStandards - 1] = '\0';
			strcpy(word1[nStandards - 1], "\0");
			strcpy(word2[nStandards - 1], "\0");
		}
	}

	for (int i = nStandards - 1; i > 0; i--) { //duplication deletion / distances
		int dupes = 0;
		for (int j = 0; j < nStandards; j++) {
			if (strcmp(word2[i], word2[j]) == 0) {
				dupes++;
			}
		}
		if (dupes > 1) {
			for (int pos = i; pos < nStandards - 1; pos++) {
				distance[pos] = distance[pos + 1];
				strcpy(word1[pos], word1[pos + 1]);
				strcpy(word2[pos], word2[pos + 1]);
			}
			distance[nStandards - 1] = '\0';
			strcpy(word1[nStandards - 1], "\0");
			strcpy(word2[nStandards - 1], "\0");
		}
	}

	for (int i = nStandards - 1; i > 0; i--) { //duplication deletion / distances
		int dupes = 0;
		for (int j = 0; j < nStandards; j++) {
			if (distance[i] == distance[j]) {
				dupes++;
			}
		}
		if (dupes > 1) {
			for (int pos = i; pos < nStandards - 1; pos++) {
				distance[pos] = distance[pos + 1];
				strcpy(word1[pos], word1[pos + 1]);
				strcpy(word2[pos], word2[pos + 1]);
			}
			distance[nStandards - 1] = '\0';
			strcpy(word1[nStandards - 1], "\0");
			strcpy(word2[nStandards - 1], "\0");
		}
	}
	
	int finalCount = 0;
	for (int i = 0; i < nStandards; i++) {
		if ((strcmp(word1[i], "\0") != 0) && (strcmp(word2[i], "\0") != 0) && distance[i] != '\0') {
			finalCount++;
		}
	}
	return finalCount;

}

int determineMatchLevel(const int distance[], const char word1[][MAX_WORD_LENGTH + 1], const char word2[][MAX_WORD_LENGTH + 1], int nStandards, const char jeet[]) {
	//run a loop until you find the word from the word array
	// if/when found, run a loop from that position to the distance in the corresponding distance array
	// Important --> do a backwards loop
	//Check if both number are there in that loop target

	if (nStandards < 0) { //negative nStandards check
		nStandards = 0;
	}

	int matchLevel = 0; //integer to return the match level of the jeet

	//Turn jeet sentence into an array
	//then search for first, last word in reverse order for word 2
	const int jeetRow = 281; //largest possible number of words
	const int jeetCol = 281; //largest possible word length/num of characters

	char jeetCopy[281] = {}; //editable copy of jeet

	int n = 0;
	int pos = 0;
	while (n < strlen(jeet)) { //put jeet into standard form, lowercase no characters
		if (isalpha(jeet[n])) {
			jeetCopy[pos] = tolower(jeet[n]);
			pos++;
		}
		else if (jeet[n] == ' ') {
			jeetCopy[pos] = jeet[n];
			pos++;
		}
		n++;
	}

	for (int i = 0; i < strlen(jeetCopy); i++) { //delete extra spaces
		if (jeetCopy[i] == ' ' && jeetCopy[i + 1] == ' ') {
			for (int k = i; k < strlen(jeetCopy) - 1; k++) {
				jeetCopy[k] = jeetCopy[k + 1];
			}
			jeetCopy[strlen(jeetCopy) - 1] = '\0';
		}
	}

	for (int i = 0; i < strlen(jeetCopy); i++) { //delete extra spaces again;
		if (jeetCopy[i] == ' ' && jeetCopy[i + 1] == ' ') {
			for (int k = i; k < strlen(jeetCopy) - 1; k++) {
				jeetCopy[k] = jeetCopy[k + 1];
			}
			jeetCopy[strlen(jeetCopy) - 1] = '\0';
		}
	}

	if (jeetCopy[0] == ' ') { //if the jeet ends up beginning with a space
		for (int i = 0; i < strlen(jeetCopy) - 1; i++) {
			jeetCopy[i] = jeetCopy[i + 1];
		}
		jeetCopy[strlen(jeetCopy) - 1] = '\0';
	}

	int assumedWords = 1;
	for (int i = 0; i < strlen(jeetCopy); i++) { //assuming the number of words based on number of spaces
		if (jeetCopy[i] == ' ') {
			assumedWords++;
		}
	}

	char newarray[jeetRow][jeetCol] = {}; //put the words in the sentence into an array for easier access and comparison

	for (int i = 0; i < jeetRow; i++) { //make jeet sentence array full of garbage data to differentiate useful data later
		strcpy(newarray[i], "\0");
	}

	//put the first word into a c string
	//put cstring into 2d cstring
	int counter = 0;
	for (int i = 0; i < assumedWords; i++) { //fill jeet sentence array with words
		for (int k = 0; k < strlen(jeetCopy); k++) {
			if (isalpha(jeetCopy[counter])) {
				newarray[i][k] = jeetCopy[counter];
				counter++;
			}
			else {
				counter++;
				break;
			}
		}
	}

	int validData = 0; //number of words in the array, kind of like nStandards

	for (int i = 0; i < jeetRow; i++) { //verify that all the proper words in jeet are now in the array
		if (strcmp(newarray[i], "\0") != 0) {
			validData++;
		}
	}

	for (int i = 0; i < nStandards; i++) { //check if the current object in the jeet sentence array matches a w1, then if a w2 is validly in front
		for (int k = 0; k < validData; k++) {
			if (strcmp(newarray[k], word1[i]) == 0) {
				if ((distance[i] + k) < validData) {
					for (int j = (distance[i] + k); j > k; j--) {
						if (strcmp(newarray[j], word2[i]) == 0) {
							matchLevel++;
							break;
						}
					}
				}
				else {
					for (int j = validData - 1; j > k; j--) {
						if (strcmp(newarray[j], word2[i]) == 0) {
							matchLevel++;
							break;
						}
					}
				}
				break;
			}

		}
	}

	return matchLevel; //number of matches

}

void editTests() {

	int standards = 7;

	int distances[7] = { 2, 4, 1, 13, 27, 1, 13 };

	char word1[][MAX_WORD_LENGTH + 1] = { "eccentric",   "space",  "ELECTRIC", "tunnel-boring", "space", "Electric", "were" };

	char word2[][MAX_WORD_LENGTH + 1] = { "billionaire", "capsule", "CAR", "equipment", "capsule", "car", "eccentric" };

	assert(editStandards(distances, word1, word2, standards) == 4);
	cout << "[editStandards] test 1 succeeded" << endl;

	standards = 2;

	assert(editStandards(distances, word1, word2, standards) == 2);
	cout << "[editStandards] test 2 succeeded" << endl;

	standards = -1;
	assert(editStandards(distances, word1, word2, standards) == 0);
	cout << "[editStandards] test 3 succeeded" << endl;

	standards = 6;
	int distances1[6] = { 2, 4, 1, 13, 27, 1 };
	char word3[][MAX_WORD_LENGTH + 1] = { "Today", "tomorrow", "", " ", "   ", "five" };
	char word4[][MAX_WORD_LENGTH + 1] = { "If", "aggrement", " ", " /", " -  ", "sorry" };

	assert(editStandards(distances1, word3, word4, standards) == 3);
	cout << "[editStandards] test 4 succeeded" << endl;

	standards = 0;
	assert(editStandards(distances1, word3, word4, standards) == 0);
	cout << "[editStandards] test 5 succeeded" << endl;

	standards = 3;
	int distances2[3] = { -99, 4, 1 };
	char word5[][MAX_WORD_LENGTH + 1] = { "eccentric", "space", "electric" };
	char word6[][MAX_WORD_LENGTH + 1] = { "billionare", "capsule", "car" };

	assert(editStandards(distances2, word5, word6, standards) == 2);
	cout << "[editStandards] test 6 succeeded" << endl;

	standards = 3;
	int distances3[3] = { 3, 3, 3 };
	char word7[][MAX_WORD_LENGTH + 1] = { "space", "space", "space" };
	char word8[][MAX_WORD_LENGTH + 1] = { "car", "car", "car" };

	assert(editStandards(distances3, word7, word8, standards) == 1);
	cout << "[editStandards] test 7 succeeded" << endl;

	cerr << "[editStandards] tests succeeded." << endl;
	
}

void matchTests() {
	cout << "-----------------------------------" << endl;
	const int standards = 4;

	int distances[7] = { 2, 4, 1, 13 };

	char word1[][MAX_WORD_LENGTH + 1] = { "eccentric",   "space",  "electric", "were" };

	char word2[][MAX_WORD_LENGTH + 1] = { "billionaire", "capsule", "car", "eccentric" };

	assert(determineMatchLevel(distances, word1, word2, standards, "The eccentric outspoken billionaire launched a space station cargo capsule.") == 2);
	cout << "[determineMatchLevel] test 1 succeeded" << endl;
	assert(determineMatchLevel(distances, word1, word2, standards, "The eccentric outspoken billionaire launched    a space capsule.") == 2);
	cout << "[determineMatchLevel] test 2 succeeded" << endl;
	assert(determineMatchLevel(distances, word1, word2, standards, "**** 2022 ****") == 0);
	cout << "[determineMatchLevel] test 3 succeeded" << endl;
	assert(determineMatchLevel(distances, word1, word2, standards, "  It's an ELECTRIC car!") == 1);
	cout << "[determineMatchLevel] test 4 succeeded" << endl;
	assert(determineMatchLevel(distances, word1, word2, standards, "space space capsule space capsule capsule") == 1);
	cout << "[determineMatchLevel] test 5 succeeded" << endl;
	assert(determineMatchLevel(distances, word1, word2, standards, "Two eccentric billionaires were space-capsule riders.") == 0);
	cout << "[determineMatchLevel] test 6 succeeded" << endl;
	const int standard = -1;
	assert(determineMatchLevel(distances, word1, word2, standard, "The eccentric outspoken billionaire launched a space station cargo capsule.") == 0);
	cout << "[determineMatchLevel] test 7 succeeded" << endl;
	const int standar = 4;
	assert(determineMatchLevel(distances, word1, word2, standar, "The eccentric-outspoken-billionaire-launched-a-space-station-cargo-capsule.") == 0);
	cout << "[determineMatchLevel] test 8 succeeded" << endl;
	assert(determineMatchLevel(distances, word1, word2, standar, "The-eccentric-outspoken-billionaire-launched-a-electric- space -station-cargo- capsule .") == 1);
	cout << "[determineMatchLevel] test 9 succeeded" << endl;
	cerr << "[determineMatchLevel] tests succeeded." << endl;
}
