#include <iostream>
#include <string>
#include <cassert>
using namespace std;

//void assertRunner(); // I don't want main to be cluttered with asserts :/
int enumerate(string arr[], int n, string target);
int findMatch(const string arr[], int n, string target);
bool findRun(const string arr[], int n, string target, int& begin, int& end);
int findMin(const string arr[], int n);
int moveToEnd(string arr[], int n, int pos);
int moveToBeginning(string arr[], int n, int pos);
int findDifference(const string arr1[], int n1, const string arr2[], int n2);
int removeDups(string arr[], int n);
bool subsequence(const string arr1[], int n1, const string arr2[], int n2);
int makeMerger(const string arr1[], int n1, const string arr2[], int n2, string result[], int max);
int divide(string arr[], int n, string divider);

int main() {

	//assertRunner();

	return 0;
}

//Function Definitions
//To whoever reviews this code the test cases are at the bottom

//Func to make sure the int n parameter in functions is not negative
bool legalNum(int n) {
	if (n < 0) {
		return false;
	}
	else {
		return true;
	}
}

int enumerate(string arr[], int n, string target) {
	if (!legalNum(n)) {
		return -1;
	}

	int count = 0;

	for (int i = 0; i < n; i++) {
		if (arr[i] == target) {
			count++;
		}
	}

	return count;
}

int findMatch(const string arr[], int n, string target) {
	if (!legalNum(n)) {
		return -1;
	}

	for (int i = 0; i < n; i++) {
		if (arr[i] == target) {
			return i;
		}
	}

	return -1;
}

bool findRun(const string arr[], int n, string target, int& begin, int& end) {
	if (!legalNum(n)) {
		return false;
	}

	int beginCopy = begin; //copy in case there is no match and needs to return false
	begin = 0;
	int endCopy = end; //copy in case there is no match and needs to return false
	end = 0;
	bool isReal = false; //assume there are no matches until there is a match

	for (int i = 0; i < n; i++) {
		if (arr[i] == target) {
			isReal = true;
			begin = i;
			end = i - 1;
			return true;
		}
	}

	if (!isReal) {
		begin = beginCopy;
		end = endCopy;
		return false;
	}

	return true;


}

int findMin(const string arr[], int n) {
	if (!legalNum(n) || n == 0) {
		return -1;
	}

	for (int i = 0; i < n; i++) { //Double for loop to compare a single object to whole array as many times as needed
		int count = 0;
		for (int j = 0; j < n; j++) {
			if (arr[i] <= arr[j]) {
				count++;
			}
		}
		if (count == n) { //if it is less than the same amount of objects as the number in the array then it is less than or equal to everything in the array
			return i;
		}
	}

	return -1;

}

int moveToEnd(string arr[], int n, int pos) {
	if (!legalNum(n)) {
		return -1;
	}

	if (!legalNum(pos)) {
		return -1;
	}

	string posCopy = arr[pos];
	int origPos = pos; //Save the original position for return
	int i;
	for (i = pos; i < n - 1; i++) {
		arr[i] = arr[i + 1];
	}

	//int newPos = i; //Save the new position just because
	arr[i] = posCopy; //Put initially deleted object at end
	return origPos;
}

int moveToBeginning(string arr[], int n, int pos) {
	if (!legalNum(n)) {
		return -1;
	}

	if (!legalNum(pos)) {
		return -1;
	}

	string posCopy = arr[pos];
	int origPos = pos; //Save the original position for return
	int i;
	for (i = pos; i > 0; i--) {
		arr[i] = arr[i - 1];
	}

	//int newPos = i; //Save the new position just because
	arr[0] = posCopy; //Put initially deleted object at end
	return origPos;
}

int findDifference(const string arr1[], int n1, const string arr2[], int n2) {
	if (!legalNum(n1) || !legalNum(n2)) {
		return -1;
	}

	if(n1 <= n2) { // This is to determing what value to use so there isnt an overflow error
		for (int i = 0; i < n1; i++) {
			if (arr1[i] != arr2[i]) { // Return once they dont match
				return i;
			}
		}
	}
	else if (n2 <= n1) {
		for (int i = 0; i < n2; i++) {
			if (arr1[i] != arr2[i]) {
				return i;
			}
		}
	}

	return -1;
}

int removeDups(string arr[], int n) {
	if (!legalNum(n)) {
		return -1;
	}

	for (int i = 0; i < n - 1; i++) { // Deleting duplicates by changing the current object into an x if the one that proceeds them is the same
		if (arr[i] == arr[i + 1]) {
			arr[i] = "x";
		}
	}

	for (int i = 0; i < n; i++) { // Moving all non x's to the front
		if (arr[i] != "x") {
			moveToBeginning(arr, n, i);
		}
	}

	int count = 0;
	for (int i = 0; i < n; i++) {
		if (arr[i] != "x") {
			count++;
		}
	}

	return count;
}

bool subsequence(const string arr1[], int n1, const string arr2[], int n2) {
	if (!legalNum(n1) || !legalNum(n2)) {
		return -1;
	}

	bool real = false; // Logic for finding matches later
	//int lasPos = 0;
	int j;
	int jSkip = 0; //To keep track of the last position of j to make sure that all matched proceed each other
	if (n1 <= n2) {
		for (int i = 0; i < n1; i++) {
			real = false;
			for (j = 0 + jSkip; j < n2; j++) {
				if (arr1[i] == arr2[j]) {
					real = true; // Immediately leave the loop once a match is found so the next loop can start right after at the last position of j
					jSkip = j;
					break;
				}
			}
			if (real == false) { // If no matches were found then return false
				return false;
			}
		}
	}
	else if (n2 <= n1) {
		for (int i = 0; i < n2; i++) {
			real = false;
			for (j = 0 + jSkip; j < n1; j++) {
				if (arr2[i] == arr1[j]) {
					real = true;
					jSkip = j;
					break;
				}
			}
			if (real == false) {
				return false;
			}
		}
	}

	return true;

}

int makeMerger(const string arr1[], int n1, const string arr2[], int n2, string result[], int max) {
	if (!legalNum(n1) || !legalNum(n2) || !legalNum(max)) {
		return -1;
	}

	if (n1 + n2 >= max) {
		return -1;
	}

	int i;
	for (i = 0; i < n1; i++) { // Add the first array to result
		result[i] = arr1[i];
	}

	for (int j = 0; j < n2; j++) { // Add the second array to result
		result[j + i] = arr2[j];
	}

	moveToBeginning(result, n1 + n2, findMin(result, n1 + n2));
	for (int k = 0; k < 5; k++) { // Basically if the current object is less than the one behind it, switch them. And do it 5 times to be sure
		for (int j = 1; j < n1 + n2 - 1; j++) {
			if (result[j] < result[j - 1]) {
				string temp = result[j];
				result[j] = result[j - 1];
				result[j - 1] = temp;
			}
		}
	}

	return n1 + n2;
}

int divide(string arr[], int n, string divider) {
	if (!legalNum(n)) {
		return -1;
	}

	if (n == 0) {
		return n;
	}

	for (int i = 0; i < n; i++) { // If the current array object is less than the divider move it to the beginning of the array
		if (arr[i] < divider) {
			moveToBeginning(arr, n, i);
		}
	}

	for (int i = 0; i < n; i++) { // Return the first position that is greater than divider
		if (arr[i] > divider) {
			return i;
		}
	}

	return n;

}

/*void assertRunner() {
	//Enumerate Tests
	string arr1[9] = {
		"clarence", "neil", "SONia", "amy", "ketanji", "ketanji", "ketanji", "amy", "amy"
	};
	assert(enumerate(arr1, 9, "amy") == 3);
	cout << "[enumerate] 1 *" << endl;
	assert(enumerate(arr1, 0, "neil") == 0);
	cout << "[enumerate] 2 *" << endl;
	assert(enumerate(arr1, -1, "clarence") == -1);
	cout << "[enumerate] 3 *" << endl;
	assert(enumerate(arr1, 9, "bill") == 0);
	cout << "[enumerate] 4 *" << endl;
	assert(enumerate(arr1, 9, "sonia") == 0);
	cout << "[enumerate] 5 *" << endl;
	cout << "[enumerate] tests succeded" << endl;

	cout << "---------------------------" << endl;

	//FindMatch Tests
	const string arr2[9] = {
		"clarence", "neil", "amy", "amy", "ketanji", "ketanji", "ketanji", "amy", "bob"
	};
	assert(findMatch(arr2, 9, "bob") == 8);
	cout << "[findMatch] 1 *" << endl;
	assert(findMatch(arr2, 4, "ketanji") == -1);
	cout << "[findMatch] 2 *" << endl;
	assert(findMatch(arr2, 9, "amy") == 2);
	cout << "[findMatch] 3 *" << endl;
	assert(findMatch(arr2, 0, "clarence") == -1);
	cout << "[findMatch] 4 *" << endl;
	assert(findMatch(arr2, -1, "amy") == -1);
	cout << "[findMatch] 5 *" << endl;
	cout << "[findMatch] tests succeeded" << endl;

	cout << "---------------------------" << endl;

	//FindRun Tests
	int b, e = 999;
	const string arr3[9] = {
		"clarence", "neil", "amy", "amy", "ketanji", "ketanji", "ketanji", "amy", "joe"
	};
	assert(findRun(arr3, 9, "amy", b, e) == true, b = 2, e = 3);
	cout << "[findRun] 1 *" << endl;
	assert(findRun(arr3, 9, "johnny", b, e) == false, b = 999, e = 999);
	cout << "[findRun] 2 *" << endl;
	assert(findRun(arr3, -1, "johnny", b, e) == false, b = 999, e = 999);
	cout << "[findRun] 3 *" << endl;
	assert(findRun(arr3, 5, "neil", b, e) == true, b = 1, e = 1);
	cout << "[findRun] 4 *" << endl;
	assert(findRun(arr3, 9, "clarence", b, e) == true, b = 0, e = 0);
	cout << "[findRun] 5 *" << endl;
	assert(findRun(arr3, 0, "joe", b, e) == false, b = 999, e = 999);
	cout << "[findRun] 6 *" << endl;
	cout << "[findMatch] tests succeeded" << endl;

	cout << "---------------------------" << endl;

	//FindMin Tests
	const string arr4[5] = {
		"john", "sonia", "samuel", "elena", "neil"
	};
	assert(findMin(arr4, -15) == -1);
	cout << "[findMin] 1 *" << endl;
	assert(findMin(arr4, 5) == 3);
	cout << "[findMin] 2 *" << endl;
	assert(findMin(arr4, 0) == -1);
	cout << "[findMin] 3 *" << endl;
	assert(findMin(arr4, 1) == 0);
	cout << "[findMin] 4 *" << endl;
	const string arr5[5] = {
		"john", "john", "john", "john", "john"
	};
	assert(findMin(arr5, 5) == 0);
	cout << "[findMin] 5 *" << endl;
	cout << "[findMin] tests succeeded" << endl;

	cout << "---------------------------" << endl;

	//MoveToEnd Tests
	string arr6[5] = {
		"john", "sonia", "samuel", "elena", "neil"
	};
	assert(moveToEnd(arr6, 5, 0) == 0, arr6 == { "sonia", "samuel", "elena", "neil", "john" });
	cout << "[moveToEnd] 1 *" << endl;
	assert(moveToEnd(arr6, 3, 1) == 1, arr6 == { "sonia", "elena", "samuel", "neil", "john" });
	cout << "[moveToEnd] 2 *" << endl;
	assert(moveToEnd(arr6, -1, 1) == -1, arr6 == { "john", "sonia", "samuel", "elena", "neil" });
	cout << "[moveToEnd] 3 *" << endl;
	assert(moveToEnd(arr6, 5, 4) == 4, arr6 == { "sonia", "samuel", "elena", "neil", "john" });
	cout << "[moveToEnd] 4 *" << endl;
	assert(moveToEnd(arr6, 0, 0) == 0, arr6 == { "sonia", "samuel", "elena", "neil", "john" });
	cout << "[moveToEnd] 5 *" << endl;
	assert(moveToEnd(arr6, 1, 0) == 0, arr6 == { "sonia", "samuel", "elena", "neil", "john" });
	cout << "[moveToEnd] 6 *" << endl;
	cout << "[moveToEnd] tests succeeded" << endl;

	cout << "---------------------------" << endl;

	//MoveToBeginning Tests
	string arr7[5] = {
		"john", "sonia", "samuel", "elena", "neil"
	};
	assert(moveToBeginning(arr7, 5, 0) == 0, arr6 == { "john", "sonia", "samuel", "elena", "neil" });
	cout << "[moveToBeginning] 1 *" << endl;
	assert(moveToBeginning(arr7, 5, 2) == 2, arr6 == { "samuel", "john", "sonia", "elena", "neil" });
	cout << "[moveToBeginning] 2 *" << endl;
	assert(moveToBeginning(arr7, -1, 2) == -1, arr6 == { "john", "sonia", "samuel", "elena", "neil" });
	cout << "[moveToBeginning] 3 *" << endl;
	assert(moveToBeginning(arr7, 5, -1) == -1, arr6 == { "john", "sonia", "samuel", "elena", "neil" });
	cout << "[moveToBeginning] 4 *" << endl;
	assert(moveToBeginning(arr7, 2, 1) == 1, arr6 == { "sonia", "john", "samuel", "elena", "neil" });
	cout << "[moveToBeginning] 5 *" << endl;
	cout << "[moveToBeginning] tests succeeded" << endl;

	cout << "---------------------------" << endl;

	//FindDifference Tests
	string arr8[5] = {
		"a,", "b", "c", "c", "d"
	};
	string arr9[4] = {
		"a,", "b", "c", "d"
	};
	assert(findDifference(arr8, 5, arr9, 4) == 3);
	cout << "[findDifference] 1 *" << endl;
	assert(findDifference(arr8, -1, arr9, 4) == -1);
	cout << "[findDifference] 2 *" << endl;
	assert(findDifference(arr8, 5, arr9, -1) == -1);
	cout << "[findDifference] 3 *" << endl;
	assert(findDifference(arr8, 0, arr9, 0) == 0);
	cout << "[findDifference] 4 *" << endl;
	assert(findDifference(arr8, 0, arr9, 3) == 0);
	cout << "[findDifference] 5 *" << endl;
	assert(findDifference(arr8, 1, arr9, 3) == 1);
	cout << "[findDifference] 6 *" << endl;
	cout << "[findDifference] tests succeeded" << endl;

	cout << "---------------------------" << endl;

	//RemoveDups Tests
	string arr10[9] = {
		 "clarence", "neil", "amy", "amy", "ketanji", "ketanji", "ketanji", "amy", "amy"
	};
	assert(removeDups(arr10, 9) == 5);
	cout << "[removeDups] 1 *" << endl;
	string arr11[9] = {
		 "clarence", "neil", "amy", "amy", "ketanji", "ketanji", "ketanji", "amy", "amy"
	};
	assert(removeDups(arr11, 4) == 3);
	cout << "[removeDups] 2 *" << endl;
	string arr12[9] = {
		 "clarence", "neil", "amy", "amy", "ketanji", "ketanji", "ketanji", "amy", "amy"
	};
	assert(removeDups(arr11, -1) == -1);
	cout << "[removeDups] 3 *" << endl;
	cout << "[removeDups] tests succeeded" << endl;

	cout << "---------------------------" << endl;

	//Subsequence Tests
	const string arr13[6] = {
		"elena", "john", "amy", "ketanji", "neil", "amy"
	};

	const string arr14[3] = {
		"john", "ketanji", "neil"
	};

	assert(subsequence(arr13, 6, arr14, 3) == true);
	cout << "[subsequence] 1 *" << endl;
	const string arr15[2] = {
		"amy", "john"
	};
	assert(subsequence(arr13, 6, arr15, 2) == false);
	cout << "[subsequence] 2 *" << endl;
	cout << "[removeDups] tests succeeded" << endl;

	cout << "---------------------------" << endl;
	
	//MakeMerger Tests
	const string arr16[5] = { "amy", "elena", "elena", "ketanji", "samuel" };
	const string arr17[4] = { "clarence", "elena", "john", "sonia" };
	string arr18[20];
	assert(makeMerger(arr16, 5, arr17, 4, arr18, 20) == 9, arr18 == { "amy", "clarence", "elena", "elena", "john", "ketanji", "samuel", "sonia" });
	cout << "[makeMerger] 1 *" << endl;
	cout << "[makeMerger] tests succeeded" << endl;

	cout << "---------------------------" << endl;

	//Divide Tests
	string arr19[6] = {
		"john", "amy", "samuel", "elena", "sonia", "neil"
	};
	assert(divide(arr19, 6, "ketanji") == 3);
	cout << "[divide] 1 *" << endl;
	string arr20[4] = {
		"john", "sonia", "amy", "neil"
	};
	assert(divide(arr20, 4, "neil") == 2);
	cout << "	[divide] 2 *" << endl;
	cout << "[divide] tests succeeded" << endl;
}*/