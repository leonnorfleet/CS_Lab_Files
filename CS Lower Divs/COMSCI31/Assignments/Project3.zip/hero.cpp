#include <iostream>
#include <string>
#include <cassert>

using namespace std;

bool hasProperSyntax(string tune);

int convertTune(string tune, string& instructions, int& badBeat);

int main() {
	//TEST CASES
	string instrs = "WOW";
	int badb = -999;
	cout << convertTune("r//g/", instrs, badb) << endl;
	assert(convertTune("r//g/", instrs, badb) == 0 && instrs == "rxg" && badb == -999);
	cout << "Test 1 Success" << endl;
	instrs = "WOW";
	badb = -999;
	assert(convertTune("r", instrs, badb) == 1 && instrs == "WOW" && badb == -999);
	cout << "Test 2 Success" << endl;
	assert(convertTune("r/y3//g/r/", instrs, badb) == 2 && instrs == "WOW" && badb == 4);
	cout << "Test 3 Success" << endl;
	assert(convertTune("r/y3//g/r/", instrs, badb) == 2 && instrs == "WOW" && badb == 4);
	cout << "Test 4 Success" << endl;
	assert(convertTune("y3//", instrs, badb) == 4 && instrs == "WOW" && badb == 3);
	cout << "Test 5 Success" << endl;
	badb = -999;
	assert(convertTune("r//y/g3///o/", instrs, badb) == 0 && instrs == "rxyGGGo" && badb == -999);
	cout << "Test 6 Success" << endl;
	instrs = "WOW";
	assert(convertTune("A/", instrs, badb) == 1 && instrs == "WOW" && badb == -999);
	cout << "Test 7 Success" << endl;
	assert(convertTune("3/", instrs, badb) == 1 && instrs == "WOW" && badb == -999);
	cout << "Test 8 Success" << endl;
	return 0;
}

//FUNCTION DEFINITIONS

bool colorCheck(char c) { //MAKE SURE LETTER CHARS ARE CORRECT
	if (isalpha(c)) {
		switch (c) {
		case 'g':
			return true;
			break;
		case 'G':
			return true;
			break;
		case 'b':
			return true;
			break;
		case'B':
			return true;
			break;
		case 'r':
			return true;
			break;
		case 'R':
			return true;
			break;
		case 'y':
			return true;
			break;
		case 'Y':
			return true;
			break;
		case 'o':
			return true;
			break;
		case 'O':
			return true;
			break;
		default:
			return false;
		}
	}
	else {
		return false;
	}
}



bool hasProperSyntax(string tune) {

	if (tune.size() <= 2) { //IF TUNE IS 0-2 CHARS

		if (tune == "") { //IF TUNE IS ""
			return true;
		}
		else {
			if (tune.size() == 1) { //IF TUNE IS 1 CHAR
				if (tune == "/") {
					return true;
				}
				else {
					return false;
				}
			}
			else { //IF TUNE IS 2 CHARS
				if (colorCheck(tune.at(0)) || tune.at(0) == '/') { //CHAR 1 HAS TO BE ALPHA OR '/'
					if (tune.at(1) == '/') { //CHAR 2 HAS TO BE '/'
						return true;
					}
					else {
						return false;
					}
				}
				else {
					return false;
				}
			}
		}
	}
	else { //IF TUNE IS 3+ CHARACTERS
		if (tune.at(tune.size() - 1) != '/') {
			return false;
		}
			for (int i = 0; i < tune.size(); i++) {
				if (colorCheck(tune.at(i))) { //IF THE CURRENT CHARACTER IS A CORRECT COLOR
					if (i < tune.size() - 1) {
						i++;
					}
					if (isdigit(tune.at(i))) { //IF THE CURRENT CHARACTER IS A NUMBER
						i++;
						if (isdigit(tune.at(i))) {
							i++;
							if (tune.at(i) != '/') {
								return false;
							}
						}
					}
					else if (tune.at(i) != '/') { //IF THE CURRENT CHARACTER IS A COLOR AND NOT FOLLOWED BY A SLASH
						return false;
					}
				}
				else if (tune.at(i) != '/') {
					return false;
				}
			}
	}
	return true;
}

int convertTune(string tune, string& instructions, int& badBeat) {
	string instruc_copy = instructions; //MAKE AN UNALTERED COPY OF INSTRUCTIONS FOR ERROR CASES
	if (!hasProperSyntax(tune)) {
		return 1;
	}
	else {
		instructions = "";
		int beatTrack = 0; //TRACKS THE CURRENT BEAT IN CASE OF ERROR
		if (tune == "") {
			instructions = instruc_copy; //ERROR SO INSTRUCTIONS SHOULD BE UNALTERED
			return 0;
		}
		for (int i = 0; i < tune.size(); i++) { //CONVERT THE TUNE CHARACTER BY CHARACTER
			if (tune.at(i) == '/') {
				instructions += 'x';
				beatTrack++;
			}
			if (colorCheck(tune.at(i))) {
				char selector = tune.at(i); //THE MOST RECENT COLOR ENCOUNTERED IN CASE OF DIGIT OR '/'
				i++;
				if (isdigit(tune.at(i))) {
					string slashCount; //USED TO COUNT THE NUMBER OF SLASHES FOLLOWING A NUMBER
					while (isdigit(tune.at(i))) {
						slashCount += tune.at(i);
						i++;
					}
					if (stoi(slashCount) < 2) { //IF THE TOTAL OF BOTH NUMBER CHARACTERS IS STILL < 2
						beatTrack++;
						badBeat = beatTrack; //RETURN THE BEAT WHERE THE ERROR IS
						instructions = instruc_copy;
						return 3;
					}
					else {
						int n = 0;
						int count = 0; //THE NUMBER OF SLASHES THAT IS ACTUALLY ENCOUNTERED
						string slashHold = tune.substr(i, stoi(slashCount)); //THE STRING WHICH IS ASSUMED TO HOLD THE CORRECT NUMBER OF SLASHES
						while (n < slashHold.size() && (n + i) < tune.size()) { //MAKE SURE THERE ARE THE CORRECT NUMBER OF SLASHES FOLLOWING A DIGIT
							if (slashHold.at(n) == '/') {
								count++;
								instructions += toupper(selector);
								n++;
								beatTrack++;
							}
							else { //IF SOMETHING OTHER THAN A SLASH IS ENCOUNTERED DURING SUSTAINED BEAT
								beatTrack++;
								badBeat = beatTrack;
								instructions = instruc_copy;
								return 2;
							}
						}
						if (count != stoi(slashCount)) { //IF THE NUMBER OF SLASHES ENCOUNTERED DOES NOT EQUAL WHAT IS EXPECTED/ENDS PREMATURELY
							instructions = instruc_copy;
							badBeat = beatTrack + 1;
							return 4;
						}
						else {
							i += stoi(slashCount) - 1; //SKIP PAST WHAT WAS JUST RECORDED IF NO ERRORS
						}
					}

				}
				else if (tune.at(i) == '/') { //IF THERE IS A '/' FOLLOWING A LETTER/COLOR
					beatTrack++;
					instructions += tolower(selector);
				}
				/*else {
					beatTrack++;
					badBeat = beatTrack;
					instructions = instruc_copy;
					return 3;
				}*/
			}
		}
	}
	return 0;
}