#include <iostream>
#include <string>
using namespace std;

int main() {
	// Variables
	const double firstRate = 5.41;
	const double secondRateHigh = 9.79;
	const double secondRateLow = 7.77;
	// high usage season = 4 - 8 -> First 23 HCF is first tier
	// low usage season = 9 - 3 -> First 15 HCF is first tier

	int initMeter;
	int finalMeter;
	string customerName;
	int monthNumber;
	double bill;

	//Inputs
	cout << "Initial meter reading: ";
	cin >> initMeter;
	cout << "Final meter reading: ";
	cin >> finalMeter;
	cin.ignore(10000, '\n');

	cout << "Customer name: ";
	getline(cin, customerName);

	cout << "Month number (1=Jan, 2=Feb, etc.): ";
	cin >> monthNumber;

	// Calculations
	double diffHCF = finalMeter - initMeter;
	double diffRemainder;

	if (monthNumber >= 4 && monthNumber <= 8) { // High Season Computation
		if ((diffHCF - 23) > 0) {
			diffRemainder = diffHCF - 23;
			bill = (23 * firstRate) + (diffRemainder * secondRateHigh);
		}
		else{
			bill = (diffHCF * firstRate);
		}
	}
	else { // Low Season Computation
		if ((diffHCF - 15) > 0) {
			diffRemainder = diffHCF - 15;
			bill = (15 * firstRate) + (diffRemainder * secondRateLow);
		}
		else{
			bill = (diffHCF * firstRate);
		}
	}

	// Output
	cout << "---" << endl;

	if (initMeter < 0) {
		cout << "The initial meter reading must not be negative." << endl;
	}
	else if (finalMeter < initMeter) {
		cout << "The final meter reading must be at least as large as the initial reading." << endl;
	}
	else if (customerName == "") {
		cout << "You must enter a customer name." << endl;
	}
	else if (monthNumber < 1 || monthNumber > 12) {
		cout << "The month number must be in the range 1 through 12." << endl;
	}
	else {
		cout.setf(ios::fixed);
		cout.precision(2);
		cout << "The bill for " << customerName << " is $" << bill << endl;
	}
	
	return 0;
}
