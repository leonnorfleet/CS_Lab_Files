#include <iostream>
#include <string>

using namespace std;

//Function One
int multiplyTwoNumbers(unsigned int m, unsigned int n);

//Function Two
int tabulationStation(int num, int digit);

//Function Three
string highFives(string n);

//Function Four
string jheriCurls(string str);

//Function Five
bool aggregationNation(const int a[], int size, int target);

//Function Six
bool onMyWayHome(string maze[], int nRows, int nCols,
	int sr, int sc, int er, int ec);

int main() {

	int test[3] = { 2, 1, 3 };

	cout << aggregationNation(test, 3, 5);
	
	return 0;
}

//Function One
int multiplyTwoNumbers(unsigned int m, unsigned int n) {
	
	if (m == 0 || n == 0) {
		return 0;
	}

	if (n == 1) {
		return m;
	}
	if (m == 1) {
		return n;
	}

	return m + multiplyTwoNumbers(m, n - 1);
}

//Function Two
int tabulationStation(int num, int digit) {

	int total = 0;
	
	if (digit < 0 || digit > 9) {
		return 0;
	}

	if (num == 0) {
		return total;
	}

	if (num % 10 == digit) {
		total++;
	}
	
	total += tabulationStation(num / 10, digit);

	return total;
}

//Function Three
string highFives(string n) {

	string rstring = "";
	
	if (n.size() < 2) {
		return n;
	}

	if (n[0] == n[1]) {
		rstring += n[0];
		rstring += "55";
	}
	else {
		rstring += n[0];
	}

	if (n.size() != 1) {
		rstring += highFives(n.substr(1, n.size()));
	}

	return rstring;
}

//Function Four
string jheriCurls(string str) {

	if (str.size() < 2) {
		return str;
	}
	
	if (str[0] != '{') {
		return jheriCurls(str.substr(1, str.size()));
	}

	if (str[str.size() - 1] != '}') {
		return jheriCurls(str.substr(0, str.size() - 1));
	}

	return "{" + str.substr(1, str.size() - 1);
}

//Function Five
bool aggregationNation(const int a[], int size, int target) {

	//by reducing target by the value of each element in the array, if it reaches zero then that means you
	//can make the target value with the sum of the values in a[]
	//otherwise if the size of the array reaches zero through recursion then the sum of the values cannot make it zero

	if (target == 0) {
		return true;
	}
	else if (size == 0) {
		return false;
	}

	if (aggregationNation(a, size - 1, target)) {
	}
	else {
		return aggregationNation(a, size - 1, target - a[size - 1]);
	}
}

//Function Six
bool onMyWayHome(string maze[], int nRows, int nCols,
	int sr, int sc, int er, int ec) {

	if (nRows < 1 || nCols < 1) {
		return false;
	}

	if (maze[sr][sc] != '.' && maze[sr][sc] != 'd') {
		return false;
	}

	if (maze[er][ec] != '.' || er < 1 || er >= nRows || ec < 1 || ec >= nCols) {
		return false;
	}

	if (sr == er && sc == ec) {
		return true;
	}

	maze[sr][sc] = 'd';
	
	if (maze[sr - 1][sc] == '.') {
		if (onMyWayHome(maze, nRows, nCols, sr - 1, sc, er, ec)) {
			return true;
		}
	}
	if (maze[sr + 1][sc] == '.') {
		if (onMyWayHome(maze, nRows, nCols, sr + 1, sc, er, ec)) {
			return true;
		}
	}
	if (maze[sr][sc - 1] == '.') {
		if (onMyWayHome(maze, nRows, nCols, sr, sc - 1, er, ec)) {
			return true;
		}
	}
	if (maze[sr][sc + 1] == '.') {
		if (onMyWayHome(maze, nRows, nCols, sr, sc + 1, er, ec)) {
			return true;
		}
	}

	return false;
}

/*
	+ 1 to sr is down/south
	- 1 to sr is up/north
	+ 1 to sc is right/east
	- 1 to sc is left/west
*/