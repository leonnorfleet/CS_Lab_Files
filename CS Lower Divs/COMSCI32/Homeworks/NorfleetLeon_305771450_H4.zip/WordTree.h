#ifndef Tree

#define Tree

#include <iostream> 
#include <string> 

typedef std::string WordType;

struct WordNode {

    WordNode(WordType value) {
        m_data = value;
        m_left = nullptr;
        m_right = nullptr;
        occurences = 0;
    }
    WordType m_data;
    int occurences;
    WordNode* m_left;
    WordNode* m_right;
    // You may add additional data members and a constructor  
    // in WordNode 
};

class WordTree {
private:
    WordNode* root;

    void FreeTree(WordNode*& p);

    int distinctCount(WordNode* p) const;

    int totalCount(WordNode* p) const;

    void cConstruct(WordNode*& target, WordNode* source);

    void streamfill(std::ostream& out, WordNode* p) const;

public:
    // default constructor             
    WordTree() : root(nullptr) { };

    // copy constructor 
    WordTree(const WordTree& rhs);

    // assignment operator 
    const WordTree& operator=(const WordTree& rhs);

    // Inserts v into the WordTree     
    void add(WordType v); //done

    // Returns the number of distinct words / nodes    
    int distinctWords() const; //done

    // Returns the total number of words inserted, including  
    // duplicate values     
    int totalWords() const; //done

    // Prints the WordTree  
    friend std::ostream& operator<<(std::ostream& out, const
        WordTree& rhs);

    // Destroys all the dynamically allocated memory in the 
    // tree 
    ~WordTree();
};
#endif // !Tree
