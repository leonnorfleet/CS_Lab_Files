#include <iostream> 
#include <string> 
#include "WordTree.h"

using namespace std;

WordTree::WordTree(const WordTree& rhs) {

	root = nullptr;

	if (rhs.root == nullptr) {
		return;
	}

	cConstruct(this->root, rhs.root);
}

void WordTree::cConstruct(WordNode*& target, WordNode* source) {

	if (source == nullptr) {
		return;
	}

	target = new WordNode(source->m_data);
	target->occurences = source->occurences;
	target->m_left = nullptr;
	target->m_right = nullptr;

	cConstruct(target->m_left, source->m_left);
	cConstruct(target->m_right, source->m_right);
}

const WordTree& WordTree::operator=(const WordTree& rhs) {
	if (this == &rhs) {
		return *this;
	}

	WordTree copy(rhs);

	WordNode* p = root;
	root = copy.root;
	copy.root = p;
	p = nullptr;
	
	return *this;
}

void WordTree::add(WordType v) {

	if (root == nullptr) {
		root = new WordNode(v);
		root->occurences++;
		return;
	}
	
	WordNode* p = root;
	
	for (;;) {
		
		if (v == p->m_data) {
			p->occurences++;
			return;
		}
		if (v < p->m_data) {
			if (p->m_left != nullptr) {
				p = p->m_left;
			}
			else {
				p->m_left = new WordNode(v);
				p->m_left->occurences++;
				return;
			}
		}
		
		else if (v > p->m_data) {
			if (p->m_right != nullptr) {
				p = p->m_right;
			}
			else {
				p->m_right = new WordNode(v);
				p->m_right->occurences++;
				return;
			}
		}
	}
}

int WordTree::distinctWords() const{
	return distinctCount(root);
}

int WordTree::distinctCount(WordNode* p) const {
	if (p == nullptr) {
		return 0;
	}

	return distinctCount(p->m_left) + 1 + distinctCount(p->m_right);
}

int WordTree::totalWords() const {
	return totalCount(root);
}

int WordTree::totalCount(WordNode* p) const {
	if (p == nullptr) {
		return 0;
	}

	return totalCount(p->m_left) + p->occurences + totalCount(p->m_right);
}

WordTree::~WordTree() {
	FreeTree(root);
}

ostream& operator<<(ostream& out, const WordTree& rhs) {
	if (rhs.root == nullptr) {
		return out;
	}

	rhs.streamfill(out, rhs.root);
	return out;
}

void WordTree::streamfill(ostream& out, WordNode* p) const{
	if (p == nullptr) {
		return;
	}

	streamfill(out, p->m_left);
	out << p->m_data << " " << p->occurences << endl;
	streamfill(out, p->m_right);
}

void WordTree::FreeTree(WordNode*& p) {
	if (p == nullptr) {
		return;
	}

	FreeTree(p->m_left);
	FreeTree(p->m_right);
	delete p;
}

