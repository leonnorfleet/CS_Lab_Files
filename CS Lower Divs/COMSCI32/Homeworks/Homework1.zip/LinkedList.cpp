#include "LinkedList.h"
#include <iostream>

using namespace std;

LinkedList::LinkedList() {
	this->head = nullptr;
}

LinkedList::LinkedList(const LinkedList& rhs) { //works correctly

	head = new Node;
	head->next = nullptr;

	Node* s;
	s = rhs.head;

	Node* p;
	p = head;

	while (s != nullptr) {
		p->value = s->value;
		p->next = new Node;
		p = p->next;
		s = s->next;
	}

	p->next = nullptr;

}

LinkedList::~LinkedList() {
	Node* p;
	p = head;

	while (p != nullptr) {
		Node* n = p->next;
		delete p;
		p = n;
	}
}

const LinkedList& LinkedList::operator=(const LinkedList& rhs) { //works correctly
	if (head == nullptr) {
		head = new Node;
		head->next = nullptr;

		Node* s;
		s = rhs.head;

		Node* p;
		p = head;

		while (s != nullptr) {
			p->value = s->value;
			p->next = new Node;
			p = p->next;
			s = s->next;
		}

		p->next = nullptr;
	}

	Node* s;
	s = rhs.head;

	Node* p;
	p = head;

	while (s != nullptr) {
		p->value = s->value;
		p->next = new Node;
		p = p->next;
		s = s->next;
	}

	p->next = nullptr;

	return *this;
}

void LinkedList::insertToFront(const ItemType& val) {
	Node* p;
	p = new Node;

	p->value = val;
	p->next = head;

	head = p;
}

void LinkedList::printList() const {
	Node* p;
	p = head;

	while (p != nullptr) {
		cout << p->value << " ";
		p = p->next;
	}
	cout << endl;
}

bool LinkedList::get(int i, ItemType& item) const {
	Node* p;
	p = head;

	int count = 0;
	while (p != nullptr) {
		if (count == i) {
			item = p->value;
			return true;
		}

		count++;
		p = p->next;
	}

	return false;
}

void LinkedList::reverseList() {
	if (head == nullptr) {
		return;
	}

	Node* p;
	p = head;

	ItemType* dList = new ItemType[this->size()];

	int i = 0;
	while (p != nullptr) {
		dList[i] = p->value;
		i++;
		p = p->next;
	}

	Node* r;
	r = head;

	i = this->size() - 1;
	while (r != nullptr) {
		r->value = dList[i];
		r = r->next;
		i--;
	}
}

void LinkedList::printReverse() const {
	if (head == nullptr) {
		printList();
		return;
	}

	Node* p;
	p = head;

	ItemType* dList = new ItemType[this->size()];

	int i = 0;
	while (p != nullptr) {
		dList[i] = p->value;
		i++;
		p = p->next;
	}

	for (int i = this->size(); i > 0; i--) {
		cout << dList[i - 1] << " ";
	}

	cout << endl;
	delete[] dList;
}

void LinkedList::append(const LinkedList& other) { //works correctly
	Node* p;
	p = other.head;

	if (head == nullptr) {
		while (p != nullptr) {
			insertToFront(p->value);
			p = p->next;
		}
		return;
	}

	Node* c;
	c = head;

	while (c->next != nullptr) {
		c = c->next;
	}

	while (p != nullptr) {
		c->next = new Node;
		c = c->next;
		c->value = p->value;

		p = p->next;
	}
	c->next = nullptr;

}

void LinkedList::swap(LinkedList& other) {//works correctly
	Node* p;
	p = head;

	Node* o;
	o = other.head;

	//store their original sizes to know when the smaller one ends
	int this_size = this->size();
	int other_size = other.size();

	//THIS LIST < OTHER LIST
	if (this_size < other_size) { //make them have the same sizes
		while (p->next != nullptr) {
			p = p->next;
			o = o->next;
		}

		while (o->next != nullptr) {
			p->next = new Node;
			p = p->next;
			o = o->next;
		}
		p->next = nullptr;
	}
	//THIS LIST > OTHER LIST
	else if (this_size > other_size) { //make them have the same sizes
		while (o->next != nullptr) {
			o = o->next;
			p = p->next;
		}

		while (p->next != nullptr) {
			o->next = new Node;
			o = o->next;

			p = p->next;
		}
		o->next = nullptr;

	}
	p = head;
	o = other.head;

	while (p != nullptr && o != nullptr) {
		ItemType temp = p->value;
		p->value = o->value;
		o->value = temp;
		o = o->next;
		p = p->next;
	}

	//This list and other list switched, so their sizes also switched
	p = head;
	o = other.head;
	
	int i= 0;
	while (i < other_size - 1) {
		p = p->next;
		i++;
	}
	Node* dTarget = p->next;
	p->next = nullptr;
	delete dTarget;

	p = head;
	o = other.head;

	i = 0;
	while (i < this_size - 1) {
		o = o->next;
		i++;
	}
	dTarget = o->next;
	o->next = nullptr;
	delete dTarget;
}

int LinkedList::size() const {
	Node* p;
	p = head;

	int size = 0;
	while (p != nullptr) {
		size++;
		p = p->next;
	}

	return size;
}