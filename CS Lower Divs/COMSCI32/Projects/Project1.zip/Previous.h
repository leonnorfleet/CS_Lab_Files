#ifndef PREVIOUS

#define PREVIOUS

#include "globals.h"

class Previous
{
public:
    Previous(int nRows, int nCols);
    bool dropACrumb(int r, int c);
    void showPreviousMoves() const;

private:
    int m_rows;
    int m_cols;
    // A matrix of integers. When the player steps on or stays at the corresponding cell,
    // the code should increment the int at the position r, c
    // So the game file will be able to transcribe the int values to letters through a switch case
    int cell[MAXROWS][MAXCOLS];
};


#endif // !PREVIOUS
