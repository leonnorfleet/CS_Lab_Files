#include "Previous.h"
#include "globals.h"
#include <string>
#include <iostream>

using namespace std;

Previous::Previous(int rows, int cols) {
	m_rows = rows;
	m_cols = cols;

	for (int r = 0; r < m_rows; r++) {
		for (int c = 0; c < m_cols; c++) {
			cell[r][c] = 0;
		}
	}
}

bool Previous::dropACrumb(int r, int c) {
	if (r < 1 || r > m_rows || c < 1 || c > m_cols) {
		return false;
	}
	else {
		cell[r - 1][c - 1]++;
		return true;
	}
}

void Previous::showPreviousMoves() const {
	char grid[MAXROWS][MAXCOLS];
	int r, c;

	
	for (r = 0; r < m_rows; r++) {
		for (c = 0; c < m_cols; c++) {
			grid[r][c] = '.';
		}
	}
	
	for (r = 0; r < m_rows; r++) {
		for (int c = 0; c < m_cols; c++) {
			char& gridChar = grid[r][c];
			if (cell[r][c] < 1) {
				gridChar = 46;
			}
			else if (cell[r][c] < 25) {
				gridChar = 64 + cell[r][c];
			}
			else {
				gridChar = 90;
			}
		}
	}
	

	clearScreen();
	for (r = 0; r < m_rows; r++) {
		for (c = 0; c < m_cols; c++) {
			cout << grid[r][c];
		}
		cout << endl;
	}

	cout << endl;

	cout << "Press Enter to continue";
	string input;
	if (getline(cin, input)) {
		return;
	}

}