#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <queue>
#include <stack>

enum type{ barrel, gold, squirt, sonar };

class StudentWorld;

struct Point
{
	Point(int x, int y) { this->x = x; this->y = y; }

	int x;
	int y;

};

class baseClass : public GraphObject //base class
{
public:
	baseClass(StudentWorld* sw, int imageID, int startX, int startY, Direction dir = right, double size = 1.0, unsigned int depth = 0)
		: GraphObject(imageID, startX, startY, dir, size, depth) {
		setVisible(true);
		isAlive = true;
		m_sw = sw;
	}

	~baseClass() {
		setVisible(false);
	}

	virtual void doSomething() = 0;

	StudentWorld* getWorld();

	bool alive() const;

	void setDead();

	void annoy(int val);

	int hp;

	int myTick;

	bool annoyed;

	bool leaving;
	
	bool bribed;

	bool falling;

	bool fell;

	bool stare;

	bool stunned;

protected:
	StudentWorld* m_sw = nullptr;

private:
	bool isAlive;
};

class Earth : public baseClass //earth class
{
public:
	Earth(int x, int y) : baseClass(nullptr, TID_EARTH, x, y, right, 0.25, 3) {}

	~Earth() {}

	virtual void doSomething() {}
};

class TunnelMan : public baseClass //tunnelman class
{
public:
	TunnelMan(StudentWorld* sw, int x, int y) : baseClass(sw, TID_PLAYER, x, y, right, 1.0, 0) {
		dug, touched = false;
		hp = 10;
	}

	~TunnelMan() {}

	virtual void doSomething();

	void increaseInven(type item);

	bool touched;

	bool dug;

private:

	bool checkDir(int direction);
};

class Boulder : public baseClass //boulder class
{
public:
	Boulder(StudentWorld* sw, int x, int y) : baseClass(sw, TID_BOULDER, x, y, down, 1.0, 1) { falling, waiting, fell = false; }

	~Boulder() {}

	virtual void doSomething();

private:

	void wait(bool state);
	void fall(bool state);

	bool waiting;

};

class Squirt : public baseClass
{
public:
	Squirt(StudentWorld* sw, int x, int y, Direction dir = down, int distance = 4) : baseClass(sw, TID_WATER_SPURT, x, y, dir, 1.0, 1) {
		initX = x;
		initY = y;
	}

	~Squirt() {}

	virtual void doSomething();

private:

	void movement();

	int initX, initY;
};

class Barrel : public baseClass
{
public:
	Barrel(StudentWorld* sw, int x, int y) : baseClass(sw, TID_BARREL, x, y, right, 1, 2) {
		setVisible(false);
	}

	~Barrel() {}

	virtual void doSomething();
};

class GoldNugget : public baseClass
{
public:
	//false is permanent, true is temporary
	GoldNugget(StudentWorld* sw, int x, int y, bool state, int tick) : baseClass(sw, TID_GOLD, x, y, right, 1, 2) {
		setVisible(state); 
		gState = state;
		myTick = tick;
	}

	~GoldNugget() {}

	virtual void doSomething();

private:
	bool gState;
};

class SonarKit : public baseClass
{
public:
	SonarKit(StudentWorld* sw, int x, int y, int tick) : baseClass(sw, TID_SONAR, x, y, right, 1, 2) {
		myTick = tick;
	}

	~SonarKit() {}

	virtual void doSomething();

private:
};

class WaterPool : public baseClass
{
public:
	WaterPool(StudentWorld* sw, int x, int y, int tick) : baseClass(sw, TID_WATER_POOL, x, y, right, 1, 2) {}

	~WaterPool() {}

	virtual void doSomething();
};

class Protester : public baseClass
{
public:
	Protester(StudentWorld* sw, int imageID, int x, int y) : baseClass(sw, imageID, x, y, left, 1, 0) {
		numSquaresToMoveInCurrentDirection = rand() % (60 - 8 + 1) + 8;
		resting, leaving, yelled, intersected, stunned, embark = false;
		
		for (int i = 0; i < 64; i++) {
			for (int j = 0; j < 64; j++) {
				myMap[i][j] = -1;
			}
		}
		
	}

	~Protester() {}

	virtual void doSomething();

protected:

	virtual void getBribed() = 0;

	int numSquaresToMoveInCurrentDirection;

	bool resting;

	bool yelled;
	
	bool intersected;

	bool embark;

	bool notHard;

	int sTick = 0;

	int yellTick = 0;

	int freezeTick = 0;

	int myMap[64][64];

	std::queue<Point> path;

	std::stack<Point> exitPath;

	void newSteps();

	Direction intersection();

	void leaveField();

	void realLeave();

};

class RegularProtester : public Protester
{
public:
	RegularProtester(StudentWorld* sw, int x, int y) : Protester(sw, TID_PROTESTER, x, y) {
		hp = 5;
		notHard = true;
	}

	~RegularProtester() {}

	virtual void doSomething();

protected:

	virtual void getBribed();

private:

};

class HardcoreProtester : public Protester
{
public:
	HardcoreProtester(StudentWorld* sw, int x, int y) : Protester(sw, TID_HARD_CORE_PROTESTER, x, y) {
		hp = 20;
		stare = false;
		notHard = false;

		for (int i = 0; i < 64; i++) {
			for (int j = 0; j < 64; j++) {
				trackMap[i][j] = -1;
			}
		}
	}

	~HardcoreProtester() {}

	virtual void doSomething();

protected:

	virtual void getBribed();

	int stepsAway();

	bool called = false;

private:
	int stareTick = 0;

	std::queue<Point> track_queue;;

	std::stack<Point> trackStack;

	int trackMap[64][64];
};

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

#endif // ACTOR_H_
