#include <iostream>
#include <fstream>
#include <istream>
#include <cstring>
#include <string>
#include <cassert>

using namespace std;
//Set stack size to 8,000,000 / 8MB

const int MAXRESULTS = 20;    // Max matches that can be found
const int MAXDICTWORDS = 30000; // Max words that can be read in 

int lexiconBuilder(istream& dictfile, string dict[]);

int theJumbler(string word, const string dict[], int size,
	string results[]);

void divulgeSolutions(const string results[], int size);

void permute(const string& prefix, const string& rest, const string dict[], const int& dict_size, string results[]);

void perm_loop(const int& i, const int& max, const string& prefix, const string& rest, const string dict[], const int& dict_size, string results[]);

bool in_dict(const int& i, const int& max, const string dict[], const string& word);

void insert_r(string results[], const string& word, const int& i, const int& results_size);

bool dupe_prevent(const int& i, const int& max, const string& word, string results[]);

int count_loop(const int& i, const int& results_size, const string results[]);

int main() {

	string results[MAXRESULTS];
	string dict[MAXDICTWORDS];
	ifstream dictfile;         // file containing the list of words
	int nwords;                // number of words read from dictionary
	string word;
	dictfile.open("words.txt");
	if (!dictfile) {
		cout << "File not found!" << endl;
		return (1);
	}
	nwords = lexiconBuilder(dictfile, dict);
	cout << "Please enter a string for an anagram: ";
	cin >> word;
	int numMatches = theJumbler(word, dict, nwords, results);
	if (!numMatches) {
		cout << "No matches found" << endl;
	}
	else {
		divulgeSolutions(results, numMatches);
	}
	return 0;
}

//Main Functions
int lexiconBuilder(istream& dictfile, string dict[]) {

	if (getline(dictfile, dict[0]) && (count_loop(0, MAXDICTWORDS, dict) < MAXDICTWORDS)) {
		return 1 + lexiconBuilder(dictfile, dict + 1);
	}

	return 0;
}

int theJumbler(string word, const string dict[], int size,
	string results[]) {

	if (size <= 0) {
		return 0;
	}

	permute("", word, dict, size, results);

	return count_loop(0, MAXRESULTS, results);
}

void divulgeSolutions(const string results[], int size) {

	if (size == 0) {
		return;
	}
	if (results[0] != "\0" && results[0] != "") {
		cout << results[0] << " ";
	}
	divulgeSolutions(results + 1, size - 1);
}

//Permutation Engine
void permute(const string& prefix, const string& rest, const string dict[], const int& dict_size, string results[]) {
	if (rest.size() == 0) {
		if (in_dict(0, dict_size, dict, prefix)) {
			if (dupe_prevent(0, MAXRESULTS, prefix, results)) {
				insert_r(results, prefix, 0, MAXRESULTS);
			}
		}
		return;
	}
	else {
		perm_loop(0, rest.size(), prefix, rest, dict, dict_size, results);
	}
}

void perm_loop(const int& i, const int& max, const string& prefix, const string& rest, const string dict[], const int& dict_size, string results[]) {
	if (i >= max) {
		return;
	}
	permute(prefix + rest[i], (rest.substr(0, i) + rest.substr(i + 1, rest.size())), dict, dict_size, results);
	perm_loop(i + 1, max, prefix, rest, dict, dict_size, results);
}

bool in_dict(const int& i, const int& max, const string dict[], const string& word) {

	if (i >= max) {
		return false;
	}
	if (dict[i] == word) {
		return true;
	}

	return in_dict(i + 1, max, dict, word);
}

void insert_r(string results[], const string& word, const int& i, const int& results_size) {

	if (i >= results_size) {
		return;
	}

	if (results[i] == "" || results[i] == "\0") {
		results[i] = word;
		return;
	}

	return insert_r(results, word, i + 1, results_size);

}

bool dupe_prevent(const int& i, const int& max, const string& word, string results[]) {
	if (i >= max) {
		return true;
	}
	if (results[i] == word) {
		return false;
	}

	return dupe_prevent(i + 1, max, word, results);
}

int count_loop(const int& i, const int& results_size, const string results[]) {
	if (i >= results_size) {
		return 0;
	}
	if (results[i] != "" || results[i] != "\0") {
		return 1 + count_loop(i + 1, results_size, results);
	}

	return 0;
}

/*
//Finding Permutations
void permute(string prefix, string rest, const string dict[], string result[], int dict_size) {

	if (rest.size() == 0) {
		word_loop(dict, prefix, result, 0, dict_size);
		return;
	}
	else {
		perm_loop(0, rest.size(), prefix, rest, dict, result, dict_size);
	}
}

//Loop for finding the permutations for each character of the word
void perm_loop(int i, int max, string prefix, string rest, const string dict[], string result[], int dict_size) {
	if (i >= max) {
		return;
	}
	permute(prefix + rest[i], rest.substr(0, i) + rest.substr(i + 1, rest.size()), dict, result, dict_size);
	perm_loop(i + 1, max, prefix, rest, dict, result, dict_size);
}

//Loop for adding permutations into results and doing duplication prevention
void word_loop(const string dict[], string word, string result[], int i, int dict_size) {

	if (i >= dict_size) {
		return;
	}
	if (dict[i] == word) {
		if (check_loop(result, dict[i])) {
			insert(0, MAXRESULTS, result, word);
			cout << word << endl;
			return;
		}
		return;
	}
	else {
		word_loop(dict, word, result, i + 1, dict_size);
	}

}

//Loop for making sure the added word is not already in results
bool check_loop(string result[], string word) {
	if (result->size() == 0) {
		return true;
	}

	if (word == result[0]) {
		return false;
	}

	return check_loop(result + 1, word);
}

//Loop for inserting the word if check_loop returns true(the word is not a duplicate)
void insert(int i, int max, string result[], string word) {
	if (i >= max) {
		return;
	}

	if (result[i] == "\0") {
		result[i] = word;
		return;
	}

	insert(i + 1, max, result, word);
}

int num_words(string result[]) {
	if (result->size() == 0 || result[0] == "\0") {
		return 0;
	}
	return 1 + num_words(result + 1);
}
*/