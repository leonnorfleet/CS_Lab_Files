#include "WeddingGuest.h"
#include <string>
#include <iostream>

using namespace std;

WeddingGuest::WeddingGuest() {

	head = nullptr;
	//head->prev = nullptr;
	//tail = nullptr;
}

WeddingGuest::WeddingGuest(const WeddingGuest& rhs) {

	if (rhs.head == nullptr) {
		return;
	}

	if (&rhs == this) {
		return;
	}

	delete this->head;

	head = nullptr;

	head = new Node;
	//head->prev = nullptr;
	head->next = nullptr;

	Node* s;
	s = rhs.head;

	Node* p;
	p = head;

	while (s->next != nullptr) {

		p->fName = s->fName;
		p->lName = s->lName;
		p->value = s->value;

		p->next = new Node;

		p = p->next;
		s = s->next;
	}

	p->next = new Node;

	p->fName = s->fName;
	p->lName = s->lName;
	p->value = s->value;

	p->next = nullptr;

	p = head;
}

WeddingGuest::~WeddingGuest() {
	Node* p;
	p = head;

	while (p != nullptr) {
		Node* n = p->next;
		delete p;
		p = n;
	}
}

const WeddingGuest& WeddingGuest::operator=(const WeddingGuest& rhs) {

	//aliasing check
	if (&rhs == this) {
		return *this;
	}

	//if other is empty
	if (rhs.head == nullptr) {
		string f, l;
		GuestType v;

		while (this->guestCount() != 0) {
			this->verifyGuestOnTheList(0, f, l, v);

			this->crossGuestOff(f, l);
		}

		return *this;
	}

	//if this is empty
	if (head == nullptr) {

		head = new Node;
		head->next = nullptr;

		Node* p = head;

		Node* o;

		for (o = rhs.head; o != nullptr; o = o->next) {
			p->fName = o->fName;
			p->lName = o->lName;
			p->value = o->value;

			p->next = new Node;

			p = p->next;
		}
		p->next = nullptr;

		return *this;
	}

	Node* p;

	Node* o;

	int i = 0;

	//if this and other hold the same values
	bool same = true;

	if (this->guestCount() != rhs.guestCount()) {
		same = false;
	}

	for (p = head; p != nullptr; p = p->next) {
		string f1, l1, f2, l2;
		GuestType v1, v2;

		this->verifyGuestOnTheList(i, f1, l1, v1);
		rhs.verifyGuestOnTheList(i, f2, l2, v2);

		if (f1 != f2 || l1 != l2 || v1 != v2) {
			same = false;
		}
	}

	if (same == true) {
		return *this;
	}

	//empty out this list
	while (this->guestCount() != 0) {
		string f, l;
		GuestType v;

		this->verifyGuestOnTheList(0, f, l, v);

		this->crossGuestOff(f, l);
	}

	for (o = rhs.head; o != nullptr; o = o->next) {

		this->inviteGuest(o->fName, o->lName, o->value);
	}

	return *this;
}

bool WeddingGuest::noGuests() const {

	if (head == nullptr) {

		return true;
	}

	return false;
}

int WeddingGuest::guestCount() const {

	Node* p;
	p = head;

	int i = 0;

	while (p != nullptr) {

		i++;
		p = p->next;
	}

	return i;
}

bool WeddingGuest::inviteGuest(const std::string& firstName, const std::string&
	lastName, const GuestType& value) {

	bool s_ln = false;
	
	//head is empty
	if (head == nullptr) {
		Node* p = new Node;
		
		p->fName = firstName;
		p->lName = lastName;
		p->value = value;

		p->next = head;
		head = p;

		head->prev = nullptr;

		return true;
	}

	//check if a full name already exists
	for (Node* p = head; p != nullptr; p = p->next) {
		if (lastName == p->lName) {
			s_ln = true;
			if (firstName == p->fName) {
				return false;
			}
		}
	}

	//check if name belongs at top of the list
	if (lastName < head->lName) {
		Node* p = new Node;

		p->fName = firstName;
		p->lName = lastName;
		p->value = value;

		p->next = head;
		head->prev = p;
		head = p;

		head->prev = nullptr;

		return true;
	}

	//check if a name belongs at the bottom of the list
	Node* p = head;
	while(p->next != nullptr) {
		p = p->next;
	}
	if (p->lName < lastName) {
		Node* n = new Node;

		n->fName = firstName;
		n->lName = lastName;
		n->value = value;

		n->next = p->next;
		n->prev = p;
		p->next = n;

		return true;
	}

	//check where to put a name, not top/bottom
	if (!s_ln) {
		Node* p;
		for (p = head; p != nullptr && lastName > p->lName; p = p->next);

		if (p != nullptr) {
			Node* n = new Node;

			n->fName = firstName;
			n->lName = lastName;
			n->value = value;

			if (p->prev != nullptr) {
				n->prev = p->prev;
				p->prev->next = n;
			}

			n->next = p;
			p->prev = n;
		}

		return true;
	}

	//check where to put name, same last name
	if (s_ln) {
		
		Node* p;
		for (p = head; p != nullptr && lastName != p->lName; p = p->next);

		if (p != nullptr) {
			
			//if it belongs at the front of the lastNames
			if (p->lName == lastName && firstName < p->fName) {
				if (p == head) {//absolute front
					Node* n = new Node;

					n->fName = firstName;
					n->lName = lastName;
					n->value = value;

					n->next = head;
					head->prev = n;
					head = n;

					head->prev = nullptr;

					return true;
				}
				else {//relative front
					Node* n = new Node;

					n->fName = firstName;
					n->lName = lastName;
					n->value = value;

					n->prev = p->prev;
					n->next = p;
					if (p->prev != nullptr) {
						p->prev->next = n;
					}
					p->prev = n;

					return true;
				}
			}

			//if it belongs at the end of the lastNames
			Node* i;
			for (i = p; i->next != nullptr && lastName == i->next->lName && firstName > p->next->fName; i = i->next);

			p = i;

			if (p->next == nullptr || p->next->lName != lastName) {

					Node* n = new Node;

					n->fName = firstName;
					n->lName = lastName;
					n->value = value;

					n->next = p->next;

					if (p->next != nullptr) {
						p->next->prev = n;
					}

					n->prev = p;

					if (p != nullptr) {
						p->next = n;
					}

					return true;
			}

			//check where to put, not top/bottom
			for (p = head; p->next != nullptr && lastName == p->next->lName && firstName > p->next->fName; p = p->next);

			if (p != nullptr) {
				if (p->lName == lastName && p->next->lName == lastName) {

					Node* n = new Node;

					n->fName = firstName;
					n->lName = lastName;
					n->value = value;

					if (n->next != nullptr) {
						n->next = p->next;
						p->next->prev = n;
					}

					n->prev = p;
					p->next = n;

					return true;

				}
			}
		}
	}
	return false;
}

bool WeddingGuest::alterGuest(const std::string& firstName, const std::string&
	lastName, const GuestType& value) {

	Node* p;
	p = head;

	while (p != nullptr) {
		if (p->fName == firstName && p->lName == lastName) {
			p->value = value;
			return true;
		}
		p = p->next;
	}

	return false;
}

bool WeddingGuest::inviteOrAlter(const std::string& firstName, const
	std::string& lastName, const GuestType& value) {

	if (alterGuest(firstName, lastName, value)) {
		return true;
	}
	else if (inviteGuest(firstName, lastName, value)) {
		return true;
	}

	return false;
}

bool WeddingGuest::crossGuestOff(const std::string& firstName, const
	std::string& lastName) {

	if (this->guestCount() == 1) {

		Node* dTarget;
		dTarget = head;

		head = dTarget->next;

		delete dTarget;

		return true;
	}

	Node* t = head;
	bool exists = false;
	while (t != nullptr) {
		if (firstName == t->fName && lastName == t->lName) {
			exists = true;
		}

		t = t->next;
	}

	if (exists == false) {
		return false;
	}

	if (firstName == head->fName && lastName == head->lName) {

		Node* dTarget;
		dTarget = head;

		head = dTarget->next;

		delete dTarget;

		return true;
	}
	
	Node* p;
	p = head;

	while (p != nullptr) {
		
		if (firstName == p->next->fName && lastName == p->next->lName) {

			Node* dTarget;
			dTarget = p->next;

			dTarget->prev->next = dTarget->next;

			if (dTarget->next != nullptr) {
				dTarget->next->prev = dTarget->prev;
			}

			delete dTarget;

			return true;
		}

		p = p->next;
	}
	

	return false;
}

bool WeddingGuest::invitedToTheWedding(const std::string& firstName, const
	std::string& lastName) const {

	Node* p;
	p = head;

	while (p != nullptr) {
		if (p->fName == firstName && p->lName == lastName) {
			return true;
		}
		p = p->next;
	}

	return false;
}

bool WeddingGuest::matchInvitedGuest(const std::string& firstName, const
	std::string& lastName, GuestType& value) const {

	Node* p;
	p = head;

	while (p != nullptr) {

		if (p->fName == firstName && p->lName == lastName) {
			value = p->value;
			return true;
		}
		p = p->next;
	}

	return false;
}

bool WeddingGuest::verifyGuestOnTheList(int i, std::string& firstName,
	std::string& lastName, GuestType& value) const {

	if (i < 0 || i > guestCount()) {
		return false;
	}

	Node* p;
	p = head;

	int n = 0;

	while (n != guestCount()) {

		if (n == i) {
			firstName = p->fName;
			lastName = p->lName;
			value = p->value;

			return true;
		}

		p = p->next;
		n++;
	}

	return false;
}

void WeddingGuest::swapWeddingGuests(WeddingGuest& other) {

	if (&other == this) {
		return;
	}

	if (other.head == nullptr) {

		int this_size_orig = this->guestCount();

		for (int i = 0; i < this_size_orig; i++) {
			string f;
			string l;
			GuestType v;

			this->verifyGuestOnTheList(i, f, l, v);

			other.inviteGuest(f, l, v);
		}

		for (int i = 0; i < this_size_orig; i++) {
			string f;
			string l;
			GuestType v;

			this->verifyGuestOnTheList(i, f, l, v);

			this->crossGuestOff(f, l);
		}

		return;
	}

	if (this->head == nullptr) {

		int other_size_orig = other.guestCount();

		for (int i = 0; i < other_size_orig; i++) {
			string f;
			string l;
			GuestType v;

			other.verifyGuestOnTheList(i, f, l, v);

			this->inviteGuest(f, l, v);
		}

		for (int i = 0; i < other_size_orig; i++) {
			string f;
			string l;
			GuestType v;

			other.verifyGuestOnTheList(i, f, l, v);

			other.crossGuestOff(f, l);
		}

		return;
	}

	int this_size_orig = this->guestCount();
	int other_size_orig = other.guestCount();

	Node* p;
	p = this->head;

	Node* o;
	o = other.head;

	//THIS LIST > OTHER LIST
	if (this_size_orig > other_size_orig) {
		while (o->next != nullptr) {
			o = o->next;
			p = p->next;
		}

		while (p->next != nullptr) {
			o->next = new Node;
			o = o->next;

			p = p->next;
		}
		o->next = nullptr;
	}
	//THIS LIST < OTHER LIST
	else if (other_size_orig > this_size_orig) {
		while (p->next != nullptr) {
			p = p->next;
			o = o->next;
		}

		while (o->next != nullptr) {
			p->next = new Node;
			p = p->next;
			o = o->next;
		}
		p->next = nullptr;
	}

	p = head;
	o = other.head;

	while (p != nullptr && o != nullptr) {
		string tempf = p->fName;
		p->fName = o->fName;
		o->fName= tempf;

		string templ = p->lName;
		p->lName = o->lName;
		o->lName = templ;

		GuestType tempv = p->value;
		p->value = o->value;
		o->value = tempv;

		o = o->next;
		p = p->next;
	}

	//This list and other list switched, so their sizes also switched
	p = head;
	o = other.head;

	int i = 0;
	while (i < other_size_orig - 1) {
		p = p->next;
		i++;
	}
	Node* dTarget = p->next;
	p->next = nullptr;
	delete dTarget;

	p = head;
	o = other.head;

	i = 0;
	while (i < this_size_orig - 1) {
		o = o->next;
		i++;
	}
	dTarget = o->next;
	o->next = nullptr;
	delete dTarget;
}

bool joinGuests (const WeddingGuest& odOne,
	const WeddingGuest& odTwo,
	WeddingGuest& odJoined) {

	if ((&odOne == &odTwo && &odTwo == &odJoined) || (&odTwo == &odOne && &odOne == &odJoined)) {
		return true;
	}

	int one_size = odOne.guestCount();
	int two_size = odTwo.guestCount();

	string f1;
	string l1;
	GuestType v1;

	string f2;
	string l2;
	GuestType v2;

	//odOne is odJoined
	if (&odOne == &odJoined) {

		bool returnValue = true;

		//Remove incorrect dupes from odOne/odJoined
		for (int i = 0; i < one_size; i++) {

			odOne.verifyGuestOnTheList(i, f1, l1, v1);

			for (int j = 0; j < two_size; j++) {

				odTwo.verifyGuestOnTheList(j, f2, l2, v2);

				if (f1 == f2 && l1 == l2) {
					if (v1 != v2) {
						odJoined.crossGuestOff(f1, l1);
						returnValue = false;
					}
				}
			}
		}

		for (int i = 0; i < two_size; i++) {

			odTwo.verifyGuestOnTheList(i, f2, l2, v2);

			odJoined.inviteGuest(f2, l2, v2);
		}

		return returnValue;
	}

	if (&odTwo == &odJoined) {
		bool returnValue = true;

		//Remove incorrect dupes from odTwo/odJoined
		for (int i = 0; i < two_size; i++) {

			odTwo.verifyGuestOnTheList(i, f2, l2, v2);

			for (int j = 0; j < one_size; j++) {

				odOne.verifyGuestOnTheList(j, f1, l1, v1);

				if (f1 == f2 && l1 == l2) {
					if (v1 != v2) {
						odJoined.crossGuestOff(f2, l2);
						returnValue = false;
					}
				}
			}
		}

		for (int i = 0; i < one_size; i++) {

			odOne.verifyGuestOnTheList(i, f1, l1, v1);

			odJoined.inviteGuest(f1, l1, v1);
		}

		return returnValue;
	}

	bool returnValue = true;
	
	int j_size = odJoined.guestCount();

	//Empty out odJoined
	for (int i = 0; i < j_size; i++) {
		string f;
		string l;
		GuestType v;

		odJoined.verifyGuestOnTheList(i, f, l, v);

		odJoined.crossGuestOff(f, l);
	}

	//Adding Unique Values from odOne
	for (int i = 0; i < one_size; i++) {

		odOne.verifyGuestOnTheList(i, f1, l1, v1);

		bool unique = true;

		for (int j = 0; j < two_size; j++) {

			odTwo.verifyGuestOnTheList(j, f2, l2, v2);

			if (f1 == f2 && l1 == l2) {
				unique = false;
			}
		}
		if (unique) {
			odJoined.inviteGuest(f1, l1, v1);
		}
	}

	//Adding Unique Values from odTwo
	for (int i = 0; i < two_size; i++) {

		odTwo.verifyGuestOnTheList(i, f2, l2, v2);

		bool unique = true;

		for (int j = 0; j < one_size; j++) {

			odOne.verifyGuestOnTheList(j, f1, l1, v1);

			if (f1 == f2 && l1 == l2) {
				unique = false;
			}
		}
		if (unique) {
			odJoined.inviteGuest(f2, l2, v2);
		}
	}

	//Incorrect Duplicate Check
	for (int i = 0; i < one_size; i++) {

		odOne.verifyGuestOnTheList(i, f1, l1, v1);

		for (int j = 0; j < two_size; j++) {

			odTwo.verifyGuestOnTheList(j, f2, l2, v2);

			if (f1 == f2 && l1 == l2) {
				if (v1 == v2) {
					odJoined.inviteGuest(f1, l1, v1);
				}
				else {
					returnValue = false;
				}
			}
		}
	}

	return returnValue;
}

void attestGuests(const std::string& fsearch, const std::string& lsearch,
	const WeddingGuest& odOne, WeddingGuest& odResult) {

	int one_size = odOne.guestCount();
	string f, l;
	GuestType v;

	if (&odResult == &odOne) {
		for (int i = 0; i < one_size; i++) {
			odOne.verifyGuestOnTheList(i, f, l, v);

			if (fsearch != "*" || lsearch != "*") {
				if (f != fsearch && l != lsearch) {
					odResult.crossGuestOff(f, l);
				}
				else if (f != fsearch && lsearch != "*") {
					odResult.crossGuestOff(f, l);
				}
				else if (l != lsearch && fsearch != "*") {
					odResult.crossGuestOff(f, l);
				}
			}
		}
		return;
	}

	//Wipe odResult
	while (odResult.guestCount() != 0) {
		odResult.verifyGuestOnTheList(0, f, l, v);

		odResult.crossGuestOff(f, l);
	}

	for (int i = 0; i < one_size; i++) {
		odOne.verifyGuestOnTheList(i, f, l, v);

		if (f == fsearch || fsearch == "*") {
			if (l == lsearch || lsearch == "*") {
				odResult.inviteGuest(f, l, v);
			}
		}
	}
	return;
}

void drop(const WeddingGuest& w) {

	for (int n = 0; n < w.guestCount(); n++)
	{
		string first;
		string last;
		GuestType val;
		w.verifyGuestOnTheList(n, first, last, val);
		cout << first << " " << last << " " << val << endl;
	}

	return;
}