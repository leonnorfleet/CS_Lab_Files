#include "StudentWorld.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

void StudentWorld::boulderGen(std::vector<baseClass*>& m_actors) {

	srand(time(0));
	int paramA = getLevel() / 2 + 2;
	int B = std::min(paramA, 9);

	int coorX, coorY;
	
	for (int i = 0; i < B; i++) {

		coorX = rand() % (59 - 1 + 1) + 1;
		coorY = rand() % (55 - 20 + 1) + 20;

		if (coorX >= 26 && coorX <= 34) {
			while (coorX >= 26 && coorX <= 34) {
				coorX = rand() % (59 - 1 + 1) + 1;
			}
		}

		bool ok = false;

		while (!ok) {
			for (int j = 0; j < m_actors.size(); j++) {
				while (sqrt((pow(m_actors[j]->getX() - coorX, 2.0) + pow(m_actors[j]->getY() - coorY, 2.0))) <= 6) {
					coorX = rand() % (59 - 1 + 1) + 1;
					coorY = rand() % (55 - 20 + 1) + 20;

					if (coorX >= 26 && coorX <= 34) {
						while (coorX >= 26 && coorX <= 34) {
							
							coorX = rand() % (59 - 1 + 1) + 1;
						}
					}
				}
			}

			bool good = true;

			for (int j = 0; j < m_actors.size(); j++) {
				if (sqrt((pow(m_actors[j]->getX() - coorX, 2.0) + pow(m_actors[j]->getY() - coorY, 2.0))) <= 6) {
					good = false;
				}
			}

			if (good) {
				ok = true;
			}
		}
		m_actors.push_back(new Boulder(this, coorX, coorY));
	}
	/*
	for (int j = 0; j < m_actors.size(); j++) {
		for (int k = 0; k < m_actors.size(); k++) {
			double x1 = m_actors[j]->getX();
			double x2 = m_actors[k]->getX();

			double y1 = m_actors[j]->getY();
			double y2 = m_actors[k]->getY();
			if (m_actors[j] == m_actors[k]) {
				std::cout << "myself\n";
			}
			else {
				std::cout << sqrt((pow(x2 - x1, 2.0) + pow(y2 - y1, 2.0))) << std::endl;
			}
		}
		std::cout << std::endl;
	}
	*/
}

void StudentWorld::earthGen(Earth* m_earth[64][64]) {
	for (int i = 0; i < 64; i++) {
		for (int j = 0; j < 64; j++) {
			if ((i < 30 || i > 33) && (j < 60)) {
				m_earth[i][j] = new Earth(i, j);
				m_earth[i][j]->setVisible(true);
			}
			else {
				if (j > 4) {
					m_earth[i][j] = new Earth(i, j);
					m_earth[i][j]->setVisible(false);
				}
				else {
					m_earth[i][j] = new Earth(i, j);
					m_earth[i][j]->setVisible(true);
				}
			}
		}
	}
}

void StudentWorld::setDisplayText() {
	int level = getLevel();
	int lives = getLives();
	int health = -99;
	int wShots = -99;
	int gold = -99;
	int remainingBarrels = -99;
	int sonar = -99;
	int score = getScore();

	string stats = " Scr: " + to_string(score) + " Lvl: " + to_string(level) + " Lives: " + to_string(lives) + " Hlth: " + to_string(health) + " Wtr: " +
		to_string(wShots) + " Gld: " + to_string(gold) + " Sonar: " + to_string(sonar) + " Oil Left: " + to_string(remainingBarrels);

	setGameStatText(stats);
	//Scr: 321000 Lvl: 52 Lives: 3 Hlth: 80% Wtr: 20 Gld: 3 Sonar: 1 Oil Left: 2 
}

void StudentWorld::dig_collisionCheck(TunnelMan& m_tman, Earth* m_earth[64][64]) { //collision detection between earth and tunnelman
	
	m_tman.dug = false;

	for (int j = 0; j < 4; j++) {
		for (int k = 0; k < 4; k++) {
			if (m_earth[m_tman.getX() + j][m_tman.getY() + k]->isVisible()) {
				m_tman.dug = true;
				m_earth[m_tman.getX() + j][m_tman.getY() + k]->setVisible(false);
				
			}
		}
	}

	if (m_tman.dug) {
		playSound(SOUND_DIG);
	}
}

void StudentWorld::cleanBoulders(Earth* m_earth[64][64], baseClass*& m_boulder) {
	for (int j = 0; j < 4; j++) {
		for (int k = 0; k < 4; k++) {
			if (m_earth[m_boulder->getX() + j][m_boulder->getY() + k]->isVisible()) {
				m_earth[m_boulder->getX() + j][m_boulder->getY() + k]->setVisible(false);
			}
		}
	}
}

std::vector<baseClass*> StudentWorld::getActors() {
	return m_actors;
}

TunnelMan* StudentWorld::getMan() {
	return m_tman;
}

bool StudentWorld::okDrop(baseClass* m_boulder) {

	for (int i = 0; i < m_actors.size(); i++) {
		if (m_actors[i] == m_boulder) {
			bool canWait = true;

			for (int j = 0; j < 4; j++) {
				if (m_earth[m_actors[i]->getX() + j][m_actors[i]->getY() - 1]->isVisible() || m_actors[i]->getY() - 1 < 0) {
					canWait = false;
				}
			}

			for (int j = 0; j < m_actors.size(); j++) {
				if (m_actors[j]->getID() == TID_BOULDER) {
					for (int k = 0; k < 4; k++) {
						if (m_actors[j]->getX() + j == m_actors[i]->getX() + j && m_actors[j]->getY() + 4 == m_actors[i]->getY()) {
							canWait = false;
						}
					}
				}
			}

			return canWait;
		}
	}

	return false;
}

void StudentWorld::checkForDead() {
	//at the beginning of every new tick, this function will check for dead ones, set them visible, and delete them, if any

	for (int i = 0; i < m_actors.size(); i++) {
		if (!m_actors[i]->alive()) {
			m_actors[i]->setVisible(false);
			std::vector<baseClass*>::iterator itr;
			itr = std::find(m_actors.begin(), m_actors.end(), m_actors[i]);

			if (itr != m_actors.end()) {
				m_actors.erase(itr);
			}
		}
	}
}