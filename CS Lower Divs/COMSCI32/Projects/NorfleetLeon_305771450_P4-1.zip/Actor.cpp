#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

void TunnelMan::doSomething() {
	//switch case using getworld to read input and move accordingly
	//checks for out of bounds movement and performs calls to studentworld to check if there are boulders in the path before moving with checkDir
	int ch;
	if (getWorld()->getKey(ch) == true) {
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			setDirection(left);
			if (getX() - 1 >= 0) {
				if (checkDir(ch)) {
					moveTo(getX() - 1, getY());
				}
			}
			break;
		case KEY_PRESS_RIGHT:
			setDirection(right);
			if (getX() + 1 <= 60) {
				if (checkDir(ch)) {
					moveTo(getX() + 1, getY());
				}
			}
			break;
		case KEY_PRESS_UP:
			setDirection(up);
			if (getY() + 1 <= 60) {
				if (checkDir(ch)) {
					moveTo(getX(), getY() + 1);
				}
			}
			break;
		case KEY_PRESS_DOWN:
			setDirection(down);
			if (getY() - 1 >= 0) {
				if (checkDir(ch)) {
					moveTo(getX(), getY() - 1);
				}
			}
			break;
		case KEY_PRESS_ESCAPE:
			hp = 0;
			//supposed to restart level and player loses 1 life but crashes game after ~2 presses
			break;
		default:
			return;
			break;
		}
	}


}

bool TunnelMan::checkDir(int direction) {
	//use getworld to access the vector of actors and search for boulders, then if the boulder's 4x4 will overlap with tunnelman's 4x4 return false
	//otherwise this function clears tunnelman to move in the direction indicated by the key
	bool canMove = true;
	switch (direction) {
	case KEY_PRESS_LEFT:
		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_BOULDER && getWorld()->getActors()[i]->isVisible()) {
				for (int j = 0; j < 4; j++) {
					for (int k = 0; k < 4; k++) {
						if (getX() == getWorld()->getActors()[i]->getX() + 4 && getY() + j == getWorld()->getActors()[i]->getY() + k) {
							canMove = false;
						}
					}
				}
			}
		}
		return canMove;
		break;
	case KEY_PRESS_RIGHT:
		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_BOULDER && getWorld()->getActors()[i]->isVisible()) {
				for (int j = 0; j < 4; j++) {
					for (int k = 0; k < 4; k++) {
						if (getX() + 4 == getWorld()->getActors()[i]->getX() && getY() + j == getWorld()->getActors()[i]->getY() + k) {
							canMove = false;
						}
					}
				}
			}
		}
		return canMove;
		break;
	case KEY_PRESS_UP:
		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_BOULDER && getWorld()->getActors()[i]->isVisible()) {
				for (int j = 0; j < 4; j++) {
					for (int k = 0; k < 4; k++) {
						if (getX() + j == getWorld()->getActors()[i]->getX() + k && getY() + 4 == getWorld()->getActors()[i]->getY()) {
							canMove = false;
						}
					}
				}
			}
		}
		return canMove;
		break;
	case KEY_PRESS_DOWN:
		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_BOULDER && getWorld()->getActors()[i]->isVisible()) {
				for (int j = 0; j < 4; j++) {
					for (int k = 0; k < 4; k++) {
						if (getX() + j == getWorld()->getActors()[i]->getX() + k && getY() == getWorld()->getActors()[i]->getY() + 4) {
							canMove = false;
						}
					}
				}
			}
		}
		return canMove;
		break;
	default:
		return false;
		break;
	}
}

void Boulder::doSomething() {
	//doSomething boulder call
	//checks if the boulder is alive to make sure behavior cant be looped by a dead boulder
	//calls to the okDrop function which constantly checks if there is a 4x1 'hole' of 'empty' earth that the boulder can fall through
	//directly under it
	//if this ever returns true the boulder immediately enters a waiting state and stores the tick this triggered at in a member int
	//when the incrementing tick counter in student world reaches the stored tick value + 30 the boulder transitions its falling state bool to true
	//when this happens, every tick the boulder checks if its still falling and okDrop still returns true
	//if okDrop returns false, a bool fall is set to false, the boulder is marked as fell, and it is set to dead
	//the next tick after this it is set to invisible
	if (!alive()) {
		return;
	}

	if (getWorld()->okDrop(this) && !waiting && !falling) {
		wait(true);
		myTick = getWorld()->tickCount;

	}

	if (waiting && myTick + 30 == getWorld()->tickCount) {
		getWorld()->playSound(SOUND_FALLING_ROCK);
		wait(false);

		fall(true);
	}

	if (falling) {
		if (getWorld()->okDrop(this)) {
			moveTo(getX(), getY() - 1);

			bool hitTman = false;

			//collision check between tunnelman and boulder, will add protesters later
			for (int j = 0; j < 4; j++) {
				for (int k = 0; k < 4; k++) {

					for (int l = 0; l < 4; l++) {
						for (int m = 0; m < 4; m++) {
							if (getX() + j == getWorld()->getMan()->getX() + l && getY() + k == getWorld()->getMan()->getY() + m) {
								if (!getWorld()->getMan()->touched) {
									hitTman = true;
									getWorld()->getMan()->touched = true;
								}
							}
						}
					}

					for (int i = 0; i < getWorld()->getActors().size(); i++) {
						if (getWorld()->getActors()[i]->getID() == TID_PROTESTER || getWorld()->getActors()[i]->getID() == TID_HARD_CORE_PROTESTER) {
							//add protester collision here
						}
					}
				}
			}

			if (hitTman) {
				getWorld()->getMan()->hp = 0;
				getWorld()->playSound(SOUND_PLAYER_GIVE_UP);
			}
		}
		else {
			fall(false);
			setDead();
			fell = true;
		}
	}
}
