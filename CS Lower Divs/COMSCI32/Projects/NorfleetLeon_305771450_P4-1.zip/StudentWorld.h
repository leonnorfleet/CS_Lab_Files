#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include "GameConstants.h"
#include <string>
#include <vector>
#include <cmath>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir) : GameWorld(assetDir) {}

	~StudentWorld() {
		cleanUp();
	}

	virtual int init()
	{

		m_tman = new TunnelMan(this, 30, 60);
		
		earthGen(m_earth);
		boulderGen(m_actors);
		
		/*//Distance Calc
		double x1 = m_actors[0]->getX();
		double x2 = m_actors[1]->getX();

		double y1 = m_actors[0]->getY();
		double y2 = m_actors[1]->getY();

		std::cout << sqrt((pow(x2 - x1, 2.0) + pow(y2 - y1, 2.0))) << std::endl;
		*///////

		for (int i = 0; i < m_actors.size(); i++) {
			if (m_actors[i]->getID() == TID_BOULDER) {
				cleanBoulders(m_earth, m_actors[i]);
			}
		}
		//std::cout << m_actors.size() << std::endl;
		return GWSTATUS_CONTINUE_GAME;
	}

	virtual int move()
	{
		// This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
		// Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
		
		tickCount++;

		checkForDead();
		
		m_tman->doSomething();

		dig_collisionCheck(*m_tman, m_earth);

		for (int i = 0; i < m_actors.size(); i++) {
			m_actors[i]->doSomething();
		}

		setDisplayText();

		if (m_tman->hp < 1) {
			decLives();
			return GWSTATUS_PLAYER_DIED;
		}

		return GWSTATUS_CONTINUE_GAME;
	}

	virtual void cleanUp()
	{
		if (m_tman != nullptr) {
			delete m_tman;
		}

		for (int i = 0; i < 64; i++) {
			for (int j = 0; j < 64; j++) {
				if (m_earth[i][j] != nullptr) {
				delete[] m_earth[i][j];
				}
			}
		}
		
		for (int i = 0; i < m_actors.size(); i++) {
			delete m_actors[i];
			m_actors[i] = nullptr;
		}
		
		m_actors.clear();
		
	}

	void boulderGen(std::vector<baseClass*>& m_actors);

	void earthGen(Earth* m_earth[64][64]);

	void setDisplayText();

	void dig_collisionCheck(TunnelMan& m_tman, Earth* m_earth[64][64]);

	void cleanBoulders(Earth* m_earth[64][64], baseClass*& m_boulder);

	std::vector<baseClass*> getActors();

	void checkForDead();


	TunnelMan* getMan();
	
	bool okDrop(baseClass* m_boulder);
	
	int tickCount = 0;

private:
	TunnelMan* m_tman = nullptr;
	Earth* m_earth[64][64];
	std::vector<baseClass*> m_actors;
};

#endif // STUDENTWORLD_H_
