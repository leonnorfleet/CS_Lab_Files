#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;

class baseClass : public GraphObject //base class
{
public:
	baseClass(StudentWorld* sw, int imageID, int startX, int startY, Direction dir = right, double size = 1.0, unsigned int depth = 0)
		: GraphObject(imageID, startX, startY, dir, size, depth) {
		setVisible(true);
		isAlive = true;
		m_sw = sw;
	}

	~baseClass() {
		setVisible(false);
	}

	virtual void doSomething() = 0;

	StudentWorld* getWorld() {
		return m_sw;
	}

	bool alive() const {
		return isAlive;
	}

	void setDead() {
		isAlive = false;
	}

	int hp;

protected:
	StudentWorld* m_sw = nullptr;

private:
	bool isAlive;
};

class Earth : public baseClass //earth class
{
public:
	Earth(int x, int y) : baseClass(nullptr, TID_EARTH, x, y, right, 0.25, 3) {}

	~Earth() {}

	virtual void doSomething() {}
};


class TunnelMan : public baseClass //tunnelman class
{
public:
	TunnelMan(StudentWorld* sw, int x, int y) : baseClass(sw, TID_PLAYER, x, y, right, 1.0, 0) {
		dug, touched = false;
		hp = 10;
	}

	~TunnelMan() {}

	virtual void doSomething();

	bool checkDir(int direction);

	bool dug;

	bool touched;
};

class Boulder : public baseClass //boulder class
{
public:
	Boulder(StudentWorld* sw, int x, int y) : baseClass(sw, TID_BOULDER, x, y, down, 1.0, 1) { falling, waiting, fell = false; }

	~Boulder() { falling, waiting = false; }

	virtual void doSomething();

	void wait(bool state) { waiting = true; }
	void fall(bool state) { falling = true; }

private:
	bool falling;
	bool waiting;
	int myTick;
	bool fell;
};

class Squirt : public baseClass
{
public:
	Squirt(StudentWorld* sw, int x, int y, Direction dir = down, int distance = 4) : baseClass(sw, TID_WATER_SPURT, x, y, dir, 1.0, 1) { travelDist = distance; }

	virtual void doSomething() {}

	int travelDist;
};

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

#endif // ACTOR_H_
