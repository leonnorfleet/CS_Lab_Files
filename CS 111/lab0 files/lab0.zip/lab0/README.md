# A Kernel Seedling
TODO: intro

## Building
```shell
TODO: cmd for build
```

## Running
```shell
TODO: cmd for running binary
```
TODO: results?

## Cleaning Up
```shell
TODO: cmd for cleaning the built binary
```

## Testing
```python
python -m unittest
```
TODO: results?

Report which kernel release version you tested your module on
(hint: use `uname`, check for options with `man uname`).
It should match release numbers as seen on https://www.kernel.org/.

```shell
uname -r -s -v
```
TODO: kernel ver?