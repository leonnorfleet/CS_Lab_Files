## UID: 305771450

## Pipe Up

C implementation of the | functionality

## Building

make

## Running

Example(assuming the only files in the directory are the tarball and the extracted files)

~$>> ./pipe ls cat wc \
      7       7      68

## Cleaning up

make clean
